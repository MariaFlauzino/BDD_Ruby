class Conta
    attr_accessor :saldo

    def initialize(saldo)
        @saldo = saldo
    end

    def saca(valor)
        if @saldo >= valor
            @saldo -= valor
            "Saque com sucesso. Muito obrigado!"
        else
            "Saldo insuficiente para saque."
        end
    end
end
