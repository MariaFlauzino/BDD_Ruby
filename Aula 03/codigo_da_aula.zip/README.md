

# Projeto Mark7
## Gerenciador de Tarefas

# Features
* Login
* Cadastro de usuários
* Cadastro de tarefas (CRUD) => Create, Read, Update and Delete
* Troca de senha
* Minha Conta (Atualização cadastral)
* Finalizar tarefa

## Sprint 1 > Login